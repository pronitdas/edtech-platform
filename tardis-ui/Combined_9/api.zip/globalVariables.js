const openaiApiKey = "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";
let questions = [];
paragraphs = [];
uploadedFile = [];
uploadedFileType = "";
